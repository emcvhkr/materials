#include <Ice/Ice.h>
#include <IceStorm/IceStorm.h>
#include "RobotDef.h"

class MyPubI : public Robot::Pub {

public:
	virtual void Notify(const ::std::string& strTopic, const ::std::string& strMsg, const ::Ice::Current& = ::Ice::Current()) override
	{
		fprintf(stdout, "[Notify] %s -> %s\n", strTopic.c_str(), strMsg.c_str());
	}

};

class MyApp : public Ice::Application {

public:
	virtual int run(int, char*[]) override
	{
		fprintf(stdout, "TopicManager.Proxy: %s\n", communicator()->getProperties()->getProperty("TopicManager.Proxy").c_str());
		IceStorm::TopicManagerPrx topicManager;
		try {
			Ice::ObjectPrx obj = communicator()->propertyToProxy("TopicManager.Proxy");
			topicManager = IceStorm::TopicManagerPrx::checkedCast(obj);
		}
		catch (Ice::Exception& e) {
			fprintf(stderr, "Error: %s\n", e.what());
		}

		Ice::ObjectAdapterPtr adapter = communicator()->createObjectAdapterWithEndpoints("PubIAdapter", "tcp");
		MyPubI* pPubI = new MyPubI;
		Ice::ObjectPrx proxy = adapter->addWithUUID(pPubI)->ice_oneway();
		adapter->activate();

		IceStorm::TopicPrx topic;
		try
		{
			topic = topicManager->retrieve("Notify");
			IceStorm::QoS qos;
			topic->subscribeAndGetPublisher(qos, proxy);
		}
		catch (const IceStorm::NoSuchTopic&)
		{
			std::cerr << "No such topic!" << std::endl;
			return EXIT_FAILURE;
		}
		fprintf(stdout, "====Wait====\n");
		shutdownOnInterrupt();
		communicator()->waitForShutdown();
		topic->unsubscribe(proxy);
		return 0;
	}

};

int main_sub(int argc, char *argv[]) {
	MyApp app;
	return app.main(argc, argv, "sub.ini");
}