#include <Ice/Ice.h>
#include "RobotDef.h"

void rpc_1(int argc, char* argv[]) {
	try
	{
		Ice::InitializationData iniData;
		iniData.properties = Ice::createProperties();
		iniData.properties->setProperty("Ice.Default.Locator", "RobotIceGrid/Locator:tcp -h 192.168.108.155 -p 4061");

		Ice::CommunicatorPtr ice = Ice::initialize(iniData);
		Ice::PropertiesPtr prop = ice->getProperties();
		fprintf(stdout, "%s : %s\n", "Ice.Config", prop->getProperty("Ice.Config").c_str());
		fprintf(stdout, "%s : %s\n", "Ice.Default.Locator", prop->getProperty("Ice.Default.Locator").c_str());

		Ice::ObjectPrx obj = ice->stringToProxy("Audio");
		Robot::AudioPrx prxAudio = Robot::AudioPrx::checkedCast(obj);

		//QByteArray str1 = QString("��Һã����ǲ���ʹ�õ�TTS").toUtf8();
		//std::string strIn = std::string(str1.data(), str1.length());

		prxAudio->TtsPlay("��Һã����ǲ���ʹ�õ�TTS"); 
		//prxAudio->begin_TtsPlay("");
		for ( int i=0; i<100; i++ )
		{
			Sleep(100);
			fprintf(stdout, "isPlaying: %d\n", prxAudio->TtsIsPlaying());
		}
		ice->waitForShutdown();
		ice->destroy();
	}
	catch (Ice::Exception& e)
	{
		fprintf(stderr, "Ice Error: %s\n", e.what());
	}
}


int main_rpc(int argc, char *argv[]) {
	fprintf(stdout, "ZeroC ICE Init Demo.\r\n");
	fprintf(stdout, "\nargc: %d\r\n", argc);
	for (int i = 0; i < argc; i++)
	{
		fprintf(stdout, "[%d] %s\r\n", i, argv[i]);
	}
	fprintf(stdout, "\n");


	fprintf(stdout, "\n***** RPC Test! *******\n");
	rpc_1(argc, argv);

	fprintf(stdout, "\n------ Over -----\n");
	system("pause");
	return 0;
}

