#include <Ice/Ice.h>
#include <Glacier2/Glacier2.h>
#include "RobotDef.h"


class MySessionCB : public Glacier2::SessionCallback {
public:
	MySessionCB() {
	}

	// ͨ�� SessionCallback �̳�
	virtual void createdCommunicator(const Glacier2::SessionHelperPtr & session) override
	{
		printf("[log]: createdCommunicator\n");
	}
	virtual void connected(const Glacier2::SessionHelperPtr & session) override
	{
		printf("[log]: connected\n");
	}
	virtual void disconnected(const Glacier2::SessionHelperPtr & session) override
	{
		printf("[log]: disconnected\n");
	}
	virtual void connectFailed(const Glacier2::SessionHelperPtr & session, const Ice::Exception & ex) override
	{
		printf("[log]: connectFailed\n");
	}
};
typedef IceUtil::Handle<MySessionCB> MySessionCBPtr;

int main(int argc, char *argv[]) {
	Ice::InitializationData iniData;
	iniData.properties = Ice::createProperties();
	// Ice.Default.Router=Glacier2/router:tcp -p 8989 -h 
	iniData.properties->setProperty("Ice.Default.Router","Glacier2/router:tcp -p 8989 -h 192.168.108.155");

	MySessionCBPtr cbSession = new MySessionCB();
	Glacier2::SessionFactoryHelperPtr _factory = new Glacier2::SessionFactoryHelper(iniData, cbSession);
	Glacier2::SessionHelperPtr _session = _factory->connect("aa", "bb");

	fprintf(stdout, "Wait 1.2s ...\n");
	Sleep(1200);
	Robot::AudioPrx prxAudio = Robot::AudioPrx::checkedCast(_session->communicator()->stringToProxy("Audio"));
	prxAudio->TtsPlay("Hay, I am Tom, where is Lucy?");

	system("pause");
	_session->destroy();
	_factory->destroy();
	return 0;
}

