#include <Ice/Ice.h>

void test_1(int argc, char* argv[]) {
	try
	{
		Ice::CommunicatorPtr ice = Ice::initialize(argc, argv);
		Ice::PropertiesPtr prop = ice->getProperties();
		fprintf(stdout, "%s : %s\n", "Ice.Config", prop->getProperty("Ice.Config").c_str());
		fprintf(stdout, "%s : %s\n", "Ice.Default.Locator", prop->getProperty("Ice.Default.Locator").c_str());
		fprintf(stdout, "%s : %s\n", "RobotPort.Endpoints", prop->getProperty("RobotPort.Endpoints").c_str());

		Ice::ObjectAdapterPtr obj = ice->createObjectAdapter("RobotPort");

		ice->destroy();
	}
	catch (Ice::Exception& e)
	{
		fprintf(stderr, "Ice Error: %s\n", e.what());
	}
}

void test_2(int argc, char* argv[]) {
	try
	{
		Ice::InitializationData iniData;
		iniData.properties = Ice::createProperties();
		iniData.properties->setProperty("Ice.Default.Locator", "RobotIceGrid/Locator:tcp -p 4061");
		iniData.properties->setProperty("RobotPort.Endpoints", "tcp -h 127.0.0.1 -p 9090");
		iniData.properties->setProperty("RobotPort.Endpoints", "tcp -h 127.0.0.1 -p 9090");

		Ice::CommunicatorPtr ice = Ice::initialize(iniData);
		Ice::PropertiesPtr prop = ice->getProperties();
		fprintf(stdout, "%s : %s\n", "Ice.Config", prop->getProperty("Ice.Config").c_str());
		fprintf(stdout, "%s : %s\n", "Ice.Default.Locator", prop->getProperty("Ice.Default.Locator").c_str());
		fprintf(stdout, "%s : %s\n", "RobotPort.Endpoints", prop->getProperty("RobotPort.Endpoints").c_str());

		Ice::ObjectAdapterPtr obj = ice->createObjectAdapter("RobotPort");

		ice->destroy();
	}
	catch (Ice::Exception& e)
	{
		fprintf(stderr, "Ice Error: %s\n", e.what());
	}
}

void test_3(int argc, char* argv[]) {
	try
	{
		Ice::StringSeq argvlist;
		argvlist.push_back("--Ice.Config=a.ini");
		argvlist.push_back("--RobotPort2.Endpoints=tcp -h 127.0.0.1 -p 9191");
		Ice::CommunicatorPtr ice = Ice::initialize(argvlist);
		Ice::PropertiesPtr prop = ice->getProperties();
		fprintf(stdout, "%s : %s\n", "Ice.Config", prop->getProperty("Ice.Config").c_str());
		fprintf(stdout, "%s : %s\n", "Ice.Default.Locator", prop->getProperty("Ice.Default.Locator").c_str());
		fprintf(stdout, "%s : %s\n", "RobotPort.Endpoints", prop->getProperty("RobotPort.Endpoints").c_str());
		fprintf(stdout, "%s : %s\n", "RobotPort2.Endpoints", prop->getProperty("RobotPort2.Endpoints").c_str());

		Ice::ObjectAdapterPtr obj = ice->createObjectAdapter("RobotPort2");

		ice->destroy();
	}
	catch (Ice::Exception& e)
	{
		fprintf(stderr, "Ice Error: %s\n", e.what());
	}
}

int main_ini(int argc, char *argv[]) {
	fprintf(stdout, "ZeroC ICE Init Demo.\r\n");
	fprintf(stdout, "\nargc: %d\r\n", argc);
	for (int i = 0; i < argc; i++)
	{
		fprintf(stdout, "[%d] %s\r\n", i, argv[i]);
	}
	fprintf(stdout, "\n");

	fprintf(stdout, "\n***** Init From Config file! *******\n");
	test_1(argc, argv);

	fprintf(stdout, "\n***** Init From Native Code! *******\n");
	test_2(argc, argv);

	fprintf(stdout, "\n***** Init From Native Code! [Error] *******\n");
	test_3(argc, argv);

	fprintf(stdout, "\n------ Over -----\n");
	system("pause");
	return 0;
}

