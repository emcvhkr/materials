# coding: utf-8

import Ice
Ice.loadSlice("RobotDemo.ice")

import Robot
print Robot
Comm = Ice.initialize()
Demo = Robot.DemoPrx.checkedCast(Comm.stringToProxy("Demo:tcp -h localhost -p 9999"))
print Demo
Demo.Hello("aaaaa")
Demo.begin_Hello("nbbbb");
Comm.destroy();
