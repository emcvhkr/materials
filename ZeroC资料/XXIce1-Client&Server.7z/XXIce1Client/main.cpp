#include <QCoreApplication>
#include "Ice/Ice.h"
#include "RobotDemo.h"
#include <QtCore>

int main(int argc, char *argv[])
{
    Ice::CommunicatorPtr pIce = Ice::initialize(argc, argv);
    Ice::ObjectPrx objPrx = pIce->stringToProxy("Demo:tcp -h localhost -p 9999");
    Robot::DemoPrx demoPrx = Robot::DemoPrx::checkedCast(objPrx);
    demoPrx->Hello("aaaa");
    demoPrx->begin_Hello("nbbbb");
    pIce->destroy();
    return 0;
}
