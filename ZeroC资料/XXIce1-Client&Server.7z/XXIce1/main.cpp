#include <QCoreApplication>
#include "Ice/Ice.h"
#include "RobotDemo.h"
#include <QtCore>

class MyDemo : public Robot::Demo{


    // Demo interface
public:
    void Hello(const std::string &str1, const Ice::Current &);
};

int main(int argc, char *argv[])
{
    //Ice::CommunicatorPtr pIce = Ice::initialize(argc, argv);
    Ice::InitializationData iniData;
    iniData.properties = Ice::createProperties();
    iniData.properties->setProperty("Robot.Endpoints","tcp -h localhost -p 9999");
    Ice::CommunicatorPtr pIce = Ice::initialize(iniData);
    try{

//    Ice::ObjectAdapterPtr adaPtr = pIce->createObjectAdapterWithEndpoints("Robot", "tcp -h localhost -p 9999");
    Ice::ObjectAdapterPtr adaPtr = pIce->createObjectAdapter("Robot");
    Ice::ObjectPtr obj = new MyDemo();
    adaPtr->add(obj, Ice::stringToIdentity("Demo"));
    adaPtr->activate();
}
    catch(Ice::Exception& e){
        qDebug()<<e.what();
    }

    pIce->waitForShutdown();
    return 0;
}

void MyDemo::Hello(const std::string &str1, const Ice::Current &)
{
    qDebug()<<"MyDemo::Hello"<<str1.c_str();
}
